import{r as o,b7 as r,j as e}from"./index-DO3Hsv6V.js";import{Wrapper as a}from"./Layout-uhXusGWS.js";import{a as s}from"./ThemeContext-CGjWYKat.js";function f(){const t=s();return o.useEffect(()=>{r(t)},[]),e.jsx(a,{titleText:"Logging out",loader:!0})}export{f as default};
//# sourceMappingURL=Logout-BlYvCcmG.js.map
