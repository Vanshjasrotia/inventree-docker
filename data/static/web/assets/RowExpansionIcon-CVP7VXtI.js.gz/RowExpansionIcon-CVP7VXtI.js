import{j as o,ac as s}from"./index-DO3Hsv6V.js";import{a}from"./IconChevronDown-XhYR5VVP.js";import{I as t}from"./IconChevronRight-CPKpJBAe.js";function m({enabled:n,expanded:r}){return o.jsx(s,{size:"sm",variant:"transparent",disabled:!n,children:r?o.jsx(a,{}):o.jsx(t,{})})}export{m as R};
//# sourceMappingURL=RowExpansionIcon-CVP7VXtI.js.map
