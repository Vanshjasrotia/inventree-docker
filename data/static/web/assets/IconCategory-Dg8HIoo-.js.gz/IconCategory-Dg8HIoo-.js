import{K as t}from"./index-DO3Hsv6V.js";/**
 * @license @tabler/icons-react v3.34.1 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */const e=[["path",{d:"M4 4h6v6h-6z",key:"svg-0"}],["path",{d:"M14 4h6v6h-6z",key:"svg-1"}],["path",{d:"M4 14h6v6h-6z",key:"svg-2"}],["path",{d:"M17 17m-3 0a3 3 0 1 0 6 0a3 3 0 1 0 -6 0",key:"svg-3"}]],a=t("outline","category","Category",e);export{a as I};
//# sourceMappingURL=IconCategory-Dg8HIoo-.js.map
