import{j as l,am as i}from"./index-DO3Hsv6V.js";function r(e){return e.visible==!1?null:l.jsx(i,{color:e.color,variant:"filled",size:e.size??"lg",children:e.label})}export{r as D};
//# sourceMappingURL=DetailsBadge-sHNY-n9a.js.map
