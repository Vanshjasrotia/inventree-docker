import{K as o}from"./index-DO3Hsv6V.js";/**
 * @license @tabler/icons-react v3.34.1 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */const a=[["path",{d:"M18 7v14l-6 -4l-6 4v-14a4 4 0 0 1 4 -4h4a4 4 0 0 1 4 4z",key:"svg-0"}]],e=o("outline","bookmark","Bookmark",a);export{e as I};
//# sourceMappingURL=IconBookmark-BnJoBX1Y.js.map
