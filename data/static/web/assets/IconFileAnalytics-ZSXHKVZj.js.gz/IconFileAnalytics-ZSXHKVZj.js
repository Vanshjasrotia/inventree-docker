import{K as a}from"./index-DO3Hsv6V.js";/**
 * @license @tabler/icons-react v3.34.1 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */const e=[["path",{d:"M12 17h-8a4 4 0 0 0 2 -3v-3a7 7 0 0 1 4 -6a2 2 0 1 1 4 0a7 7 0 0 1 4 6v.5",key:"svg-0"}],["path",{d:"M19.001 19m-2 0a2 2 0 1 0 4 0a2 2 0 1 0 -4 0",key:"svg-1"}],["path",{d:"M19.001 15.5v1.5",key:"svg-2"}],["path",{d:"M19.001 21v1.5",key:"svg-3"}],["path",{d:"M22.032 17.25l-1.299 .75",key:"svg-4"}],["path",{d:"M17.27 20l-1.3 .75",key:"svg-5"}],["path",{d:"M15.97 17.25l1.3 .75",key:"svg-6"}],["path",{d:"M20.733 20l1.3 .75",key:"svg-7"}],["path",{d:"M9 17v1a3 3 0 0 0 3 3",key:"svg-8"}]],l=a("outline","bell-cog","BellCog",e);/**
 * @license @tabler/icons-react v3.34.1 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */const t=[["path",{d:"M14 3v4a1 1 0 0 0 1 1h4",key:"svg-0"}],["path",{d:"M17 21h-10a2 2 0 0 1 -2 -2v-14a2 2 0 0 1 2 -2h7l5 5v11a2 2 0 0 1 -2 2z",key:"svg-1"}],["path",{d:"M9 17l0 -5",key:"svg-2"}],["path",{d:"M12 17l0 -1",key:"svg-3"}],["path",{d:"M15 17l0 -3",key:"svg-4"}]],v=a("outline","file-analytics","FileAnalytics",t);export{l as I,v as a};
//# sourceMappingURL=IconFileAnalytics-ZSXHKVZj.js.map
