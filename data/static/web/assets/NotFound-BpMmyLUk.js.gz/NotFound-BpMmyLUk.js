import{j as r,ab as o}from"./index-DO3Hsv6V.js";import{E as t}from"./GenericErrorPage-DxYcKmpr.js";import"./ThemeContext-CGjWYKat.js";function a(){return r.jsx(t,{title:o._({id:"boJlGf"}),message:o._({id:"CcD0eu"})})}export{a as default};
//# sourceMappingURL=NotFound-BpMmyLUk.js.map
