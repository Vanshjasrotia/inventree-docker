import{j as s,ab as r}from"./index-DO3Hsv6V.js";import{E as i}from"./GenericErrorPage-DxYcKmpr.js";function t(){return s.jsx(i,{title:r._({id:"JUwB5j"}),message:r._({id:"H//rsn"})})}export{t as P};
//# sourceMappingURL=PermissionDenied-CwPe-5Cn.js.map
