import{K as o}from"./index-DO3Hsv6V.js";/**
 * @license @tabler/icons-react v3.34.1 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */const e=[["path",{d:"M5 12l14 0",key:"svg-0"}],["path",{d:"M13 18l6 -6",key:"svg-1"}],["path",{d:"M13 6l6 6",key:"svg-2"}]],n=o("outline","arrow-right","ArrowRight",e);/**
 * @license @tabler/icons-react v3.34.1 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */const t=[["path",{d:"M4 7v-1a2 2 0 0 1 2 -2h2",key:"svg-0"}],["path",{d:"M4 17v1a2 2 0 0 0 2 2h2",key:"svg-1"}],["path",{d:"M16 4h2a2 2 0 0 1 2 2v1",key:"svg-2"}],["path",{d:"M16 20h2a2 2 0 0 0 2 -2v-1",key:"svg-3"}],["path",{d:"M5 11h1v2h-1z",key:"svg-4"}],["path",{d:"M10 11l0 2",key:"svg-5"}],["path",{d:"M14 11h1v2h-1z",key:"svg-6"}],["path",{d:"M19 11l0 2",key:"svg-7"}]],s=o("outline","barcode","Barcode",t);/**
 * @license @tabler/icons-react v3.34.1 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */const a=[["path",{d:"M6 9l6 6l6 -6",key:"svg-0"}]],v=o("outline","chevron-down","ChevronDown",a);export{s as I,v as a,n as b};
//# sourceMappingURL=IconChevronDown-XhYR5VVP.js.map
