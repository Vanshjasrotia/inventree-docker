import{d0 as o,r as s,j as r,ab as c,cT as n}from"./index-DO3Hsv6V.js";import{Wrapper as i}from"./Layout-uhXusGWS.js";import{a as u,u as p}from"./ThemeContext-CGjWYKat.js";function g(){const t=u(),e=p(),a=o(n,300);return s.useEffect(()=>{a(t,e?.state)},[t]),r.jsx(i,{titleText:c._({id:"ps9k8Y"}),loader:!0})}export{g as default};
//# sourceMappingURL=LoggedIn-BYfybQjM.js.map
