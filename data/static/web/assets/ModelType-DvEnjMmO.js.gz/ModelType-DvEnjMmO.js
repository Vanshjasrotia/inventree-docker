import{aC as e}from"./index-DO3Hsv6V.js";function a(l){return{...e[l],label:e[l].label(),label_multiple:e[l].label_multiple()}}export{a as g};
//# sourceMappingURL=ModelType-DvEnjMmO.js.map
